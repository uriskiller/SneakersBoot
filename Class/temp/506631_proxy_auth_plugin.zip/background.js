
                        var config = {
                                mode: "fixed_servers",
                                rules: {
                                  singleProxy: {
                                    scheme: "http",
                                    host: "138.201.151.74",
                                    port: parseInt(5959)
                                  },
                                  bypassList: ["localhost"]
                                }
                              };

                        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

                        function callbackFn(details) {
                            return {
                                authCredentials: {
                                    username: "SP22766162-cc-mx-sid-77229",
                                    password: "S7rnukrz"
                                }
                            };
                        }

                        chrome.webRequest.onAuthRequired.addListener(
                                    callbackFn,
                                    {urls: ["<all_urls>"]},
                                    ['blocking']
                        );
                        